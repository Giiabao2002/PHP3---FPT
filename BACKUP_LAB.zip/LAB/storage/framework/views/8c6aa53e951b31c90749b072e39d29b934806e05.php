

<?php $__env->startSection('title'); ?>
    Chi Tiet Tin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .card-title{
        font-size: 20px;
    }

    .card-text{
        font-size: 16px;
    }
</style>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    

<!-- custom cursors  -->
<div class="cursor-1"></div>
<div class="cursor-2"></div>



<div id="menu-bars" class="fas fa-bars"></div>
    
<section class="home" id="home">

    <div class="content">
        <span class="hi"> chitiettin </span>
        <div class="hot-post">
            <div class="" style="display: flex;flex-direction: row;flex-wrap: wrap;box-sizing: border-box">
            <h3> <?php echo e($tin->tieuDe); ?> </h3>
            <h4> <?php echo e($tin->tomTat); ?> </h4>
            <p id="noidung"> <?php echo $tin->noiDung; ?> </p>
        </div>
    </div>
</section>


</body>
</html>
<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rautr\OneDrive\Máy tính\php3\LAB\resources\views/chitiettin.blade.php ENDPATH**/ ?>