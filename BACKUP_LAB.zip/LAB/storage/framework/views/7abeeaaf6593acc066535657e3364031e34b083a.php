<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="<?php echo e(asset("css/formcss.css")); ?>">
</head>
<body>
	<script src=<?php echo e(asset("js/script.js")); ?>></script>
</body>
</html><?php /**PATH C:\Users\rautr\OneDrive\Máy tính\php3\LAB\resources\views/components/form.blade.php ENDPATH**/ ?>