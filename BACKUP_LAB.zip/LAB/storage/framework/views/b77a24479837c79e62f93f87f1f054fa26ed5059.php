

<?php $__env->startSection('title'); ?>
    Tin Xem Nhieu
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<style>
    .card-title{
        font-size: 20px;
    }

    .card-text{
        font-size: 16px;
    }
</style>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
<!-- custom cursors  -->
<div class="cursor-1"></div>
<div class="cursor-2"></div>


<div id="menu-bars" class="fas fa-bars"></div>
    

<section class="home" id="home">

    <div class="content">
        <span class="hi"> tinxemnhieu </span>
        <h3> ĐÂY LÀ  <span> TRANG TIN XEM NHIỀU </span> </h3>
        <div class="hot-post">
            <div class="" style="display: flex;flex-direction: row;flex-wrap: wrap;box-sizing: border-box">
                
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="flex-basis: 33.333%;margin:16px -12px;padding: 10px 12px;">
                        <a href="<?php echo e(route('chitiettin',['id'=>$value->id])); ?>" class="card w-100" style="color:black;">
                            <div class="card-body" style="padding: 0 20px;height: 100%;">
                                <img src="<?php echo e(asset('images/no-image.png')); ?>" alt="no-image" style="width: 100%;">
                              <h4 class="card-title"><?php echo e($value->tieuDe); ?></h4>
                              <p class="card-text"><b>Lượt Xem: </b><?php echo e($value->xem); ?></p>
                              <a href="#" class="btn btn-primary">See More</a>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
          
    </div>
</section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rautr\OneDrive\Máy tính\php3\LAB\resources\views/tinxemnhieu.blade.php ENDPATH**/ ?>