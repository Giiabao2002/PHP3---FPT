<p>Bonjou<?=Auth::user()->name?></p>
<h1>Đây là trang quản trị</h1><?php /**PATH C:\Users\rautr\OneDrive\Máy tính\php3\LAB\resources\views/quantri.blade.php ENDPATH**/ ?>