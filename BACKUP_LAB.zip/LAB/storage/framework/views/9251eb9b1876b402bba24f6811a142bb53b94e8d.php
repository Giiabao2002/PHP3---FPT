<header>

    <a href="#" class="logo"> <span>NGUYỄN ĐINH<br></span>GIA BẢO</a>

    <nav class="navbar">
        <a href="<?php echo e(route('trangchu')); ?>">TRANG CHỦ</a>
        <a href="<?php echo e(route('tinmoi')); ?>">TIN MỚI</a>
        <a href="<?php echo e(route('thongtinsv')); ?>">THÔNG TIN SV</a>
        <a href="<?php echo e(route('tinxemnhieu')); ?>">TIN XEM NHIỀU</a>
        <a href="<?php echo e(route('danhsachtin')); ?>">DANH SÁCH TIN</a>
        <a href="<?php echo e(route('hs')); ?>">NHẬP THÔNG TIN HS</a>
        <a href="<?php echo e(route('sv')); ?>">NHẬP THÔNG TIN SV</a>
    </nav>

    <div class="follow">
        <h2 style="color:aliceblue; ">QUẢN TRỊ ADMIN</h2><br>
        <a href="<?php echo e(route('danhsachtin')); ?>" class="fa fa-th-large"></a>
        <a href="<?php echo e(route('themtin')); ?>" class="fa fa-plus-circle"></a>
        <a href="<?php echo e(route('quantritin')); ?>" class="fa fa-user-circle"></a>
    </div>

</header>
<?php /**PATH C:\Users\rautr\OneDrive\Máy tính\php3\LAB\resources\views/components/sidebar.blade.php ENDPATH**/ ?>