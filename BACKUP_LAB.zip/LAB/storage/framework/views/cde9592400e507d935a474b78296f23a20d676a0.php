

<?php $__env->startSection('title'); ?>
    laytin1tin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    

<!-- custom cursors  -->
<div class="cursor-1"></div>
<div class="cursor-2"></div>



<div id="menu-bars" class="fas fa-bars"></div>
    
<section class="home" id="home">

    <div class="content">
        <span class="hi"> tinxemnhieu </span>
        <h3> ĐÂY LÀ TRANG CHI TIẾT CỦA TIN CÓ ID LÀ  <span> <?php echo e($id); ?> </span></h3>
        <div class="hot-post">
            
        </div>
          
    </div>
</section>


</body>
</html>
<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rautr\OneDrive\Máy tính\php3\LAB\resources\views/chitiet.blade.php ENDPATH**/ ?>