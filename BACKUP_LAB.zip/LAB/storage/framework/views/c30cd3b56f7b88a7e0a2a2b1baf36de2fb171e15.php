
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset("css/formcss.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Thêm Tin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    

<!-- custom cursors  -->
<div class="cursor-1"></div>
<div class="cursor-2"></div>

<div id="menu-bars" class="fas fa-bars"></div>

<form action="<?php echo e(route('themtin_')); ?>" method="POST" >
  <?php echo csrf_field(); ?>
<div class="wrapper">
  <div class="title">
    Thêm Tin
  </div>
  <div class="form">
     <div class="inputfield">
        <label>Tiêu Đề</label>
        <input name="tieuDe" type="text" class="input">
     </div>  
    <div class="inputfield">
        <label>Url Hình</label>
        <input name="urlHinh" type="text" class="input">
     </div>
     <div class="inputfield">
      <label>Tóm Tắt</label>
      <textarea name="tomTat" class="textarea"></textarea>
   </div>  
      <div class="inputfield">
        <label>idLT</label>
        <div class="custom_select">
          <select name="idLT">
            <option value="1">Du lịch</option>
            <option value="3">Xã hội</option>
          </select>
        </div>
     </div> 
    
    <div class="inputfield">
      <input type="submit" value="Thêm tin" class="btn">
    </div>
  </div>
</div>	
</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rautr\OneDrive\Máy tính\php3\LAB\resources\views/Tin/themtin.blade.php ENDPATH**/ ?>