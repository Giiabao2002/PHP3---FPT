
<?php $__env->startSection('css'); ?>
<link rel="stylesheet" href="<?php echo e(asset("css/formcss.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('title'); ?>
    Nhập Học Sinh
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    

<!-- custom cursors  -->
<div class="cursor-1"></div>
<div class="cursor-2"></div>

<div id="menu-bars" class="fas fa-bars"></div>


<?php if($errors->any()): ?>
    <div style="color: red;font-size: 12px"  class="wrapper">
        <ul>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>
<?php endif; ?>

<form action="<?php echo e(route('hs_store')); ?>" method="POST" >
  <?php echo csrf_field(); ?>
<div class="wrapper">
  <div class="title">
    Nhập Thông Tin Học Sinh
  </div>
  <div class="form">
     <div class="inputfield">
        <label>Họ Tên</label>
            <div style="display: flex; flex-direction: column; width: 100%">
               <?php $__errorArgs = ['hoten'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                  <span class="alert alert-danger"><?php echo e($message); ?></span>
               <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
               <input name="hoten" type="text" class="input" value="<?php echo e(old('hoten')); ?>">
            </div>
     </div>
     <div class="inputfield">
      <label>Tuổi</label>
          <div style="display: flex; flex-direction: column; width: 100%">
             <?php $__errorArgs = ['tuoi'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <span class="alert alert-danger"><?php echo e($message); ?></span>
             <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
             <input name="tuoi" type="text" class="input" value="<?php echo e(old('tuoi')); ?>">
          </div>
   </div>
   <div class="inputfield">
    <label>Ngày Sinh</label>
        <div style="display: flex; flex-direction: column; width: 100%">
           <?php $__errorArgs = ['ngaysinh'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
              <span class="alert alert-danger"><?php echo e($message); ?></span>
           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
           <input name="ngaysinh" type="text" class="input" value="<?php echo e(old('ngaysinh')); ?>">
        </div>
    </div>
    <div class="inputfield">
      <input type="submit" value="Lưu thông tin" class="btn">
    </div>
  </div>
</div>	
</form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rautr\OneDrive\Máy tính\php3\LAB\resources\views/nhaphs.blade.php ENDPATH**/ ?>