<p>Bonjou<?=Auth::user()->name?></p>
<h1>Đây là trang quản trị</h1>