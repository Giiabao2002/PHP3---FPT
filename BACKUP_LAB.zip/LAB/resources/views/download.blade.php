<p>Hello <?=Auth::user()->name?></p>
<p>Hello đây là trang dành cho người dẵ đăng nhập</p>
<p><a href="thoat">Thoát</a></p>
