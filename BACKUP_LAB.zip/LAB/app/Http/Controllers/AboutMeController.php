<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class AboutMeController extends Controller
{
       // rou about me
       function aboutme(){
        return view('aboutme');
    }
}
