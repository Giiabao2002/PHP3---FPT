<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
    <?php echo $__env->yieldContent('title'); ?>
    </title>

    <!-- font awesome cdn link  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.3/css/all.min.css">

    <!-- custom css file link  -->

    <link rel="stylesheet" href=<?php echo e(asset("css/style.css")); ?>>
    <?php echo $__env->yieldContent('css'); ?>
</head>

    <body>
        <?php echo $__env->make('components.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->yieldContent('content'); ?>
        
        <?php echo $__env->yieldContent('js'); ?>
        <script src=<?php echo e(asset("js/script.js")); ?>></script>
    </body>
</html><?php /**PATH C:\Users\rautr\OneDrive\Máy tính\php3\LAB\resources\views/components/layout.blade.php ENDPATH**/ ?>