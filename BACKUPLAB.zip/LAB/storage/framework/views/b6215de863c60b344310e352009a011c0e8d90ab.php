

<?php $__env->startSection('title'); ?>
    Danh Sach Tin
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<style>
    .card-title{
        font-size: 20px;
    }

    .card-text{
        font-size: 16px;
    }
</style>    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    
<!-- custom cursors  -->
<div class="cursor-1"></div>
<div class="cursor-2"></div>


<div id="menu-bars" class="fas fa-bars"></div>
    

<section class="home" id="home">

    <div class="content">
        <span class="hi"> danhsachtin </span>
        <h3> ĐÂY LÀ  <span> TRANG DANH SÁCH TIN</span> </h3>
        <div class="hot-post">
            <div class="" style="display: flex;flex-direction: row;flex-wrap: wrap;box-sizing: border-box">
                
                <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tin): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div style="flex-basis: 33.333%;margin:16px -12px;padding: 10px 12px;">
                        <a href="<?php echo e(route('chitiettin',['id'=>$tin->id])); ?>" class="card w-100" style="color:black;">
                            <div class="card-body" style="padding: 0 20px;height: 100%;">
                                <img src="<?php echo e(asset('images/no-image.png')); ?>" alt="no-image" style="width: 100%;">
                              <h4 class="card-title"><?php echo e($tin->tieuDe); ?></h4>
                              <p class="card-text"><?php echo e($tin->tomTat); ?></p>
                              <a href="<?php echo e(route('capnhattin', ['id'=>$tin->id])); ?>" class="btn btn-primary">CẬP NHẬT</a>                              
                              <a href="<?php echo e(route('xoatin', ['id'=>$tin->id])); ?>" class="btn btn-primary">XÓA</a>
                            </div>
                        </a>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
          
    </div>
</section>
<?php $__env->stopSection(); ?>



<?php echo $__env->make('components.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rautr\OneDrive\Máy tính\php3\LAB\resources\views/Tin/danhsach.blade.php ENDPATH**/ ?>